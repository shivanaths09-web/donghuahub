DONGHUAHUB PRO STARTER

FILES
- index.html: complete responsive website.

WHAT IS INCLUDED
- Home/catalog
- Search
- Genre filter
- Series pages
- On-site iframe/direct-video player
- Episode navigation
- Content manager
- Poster URL field
- Mobile responsive layout
- Local browser storage for testing

IMPORTANT
The sample video URL is a demo placeholder. Replace it with video/embed URLs you own or are authorized to embed. A host can block embedding.

TO PUBLISH FOR FREE
1. Extract the ZIP.
2. Upload index.html to Netlify, Cloudflare Pages, or GitHub Pages.
3. For a real admin system accessible from multiple devices, add a backend/database and authentication.
4. Do not put database/API secrets in index.html.

NEXT UPGRADE
Use Supabase/Firebase (or another backend) for:
- Login-protected admin
- Cloud database
- Thousands of series/episodes
- Image storage
- Multiple video sources per episode
- User watchlists
- Comments
- Analytics
